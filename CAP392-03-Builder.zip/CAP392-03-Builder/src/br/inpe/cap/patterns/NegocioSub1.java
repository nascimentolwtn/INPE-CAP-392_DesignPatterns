package br.inpe.cap.patterns;

public class NegocioSub1 extends NegocioBasico {

	@Override
	protected String sulfixo() {
		return "sub1";
	}
	
}
