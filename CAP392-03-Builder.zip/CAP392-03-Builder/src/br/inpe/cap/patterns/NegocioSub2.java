package br.inpe.cap.patterns;

public class NegocioSub2 extends NegocioBasico {

	@Override
	protected String sulfixo() {
		return "sub2";
	}
	
}
