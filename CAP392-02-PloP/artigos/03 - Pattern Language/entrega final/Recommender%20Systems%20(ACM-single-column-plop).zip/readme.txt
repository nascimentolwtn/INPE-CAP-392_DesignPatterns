ACM Transactions and Journals (Large Size)
------------------------------------------

The following files are available in acmlarge.zip archive:

acmlarge.cls	     - This is the LaTeX2e class file for acmlarge template
acmlarge.bst	     - This is the bibliography style file for acmlarge template
acmlarge-sam.bib     - This is the bibliography database file
acmlarge-guide.pdf   - This is PDF of Author Guide for acmlarge template
acmlarge-sample.pdf  - This is PDF file of sample LaTeX document for acmlarge template

acmlarge-sample.tex  - LaTeX document of sample
acmlarge-sample.bbl  - LaTeX document of bibliography list
acmlarge-mouse.eps	 - Graphics file used in sample
acmlarge-mouse.pdf	 - Pdf format of graphics file, compatible with pdflatex
algorithm2e.sty	     - Algorithm package used in sample

Happy TeXing!!!

Aptara